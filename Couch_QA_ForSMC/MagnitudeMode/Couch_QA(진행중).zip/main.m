clc
clear
close all

